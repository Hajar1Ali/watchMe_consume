package com.example.android.watch_me_consume;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class adapter2  extends ArrayAdapter<Product> {
    String redBar="#f6335d";
    String greenBar="#4df633";
    String yellowBar="#f6f333";
    public adapter2(@NonNull Context context, List<Product> list) {
        super(context, 0,list);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.new_expire_list, parent, false);
        }

            Product product = getItem(position);
                TextView barColort = (TextView) listItemView.findViewById(R.id.barColor_text_view);
                barColort.setBackgroundColor(Color.parseColor(redBar));

                TextView name = (TextView) listItemView.findViewById(R.id.t1);
                name.setText(product.getName());

                TextView quantity = (TextView) listItemView.findViewById(R.id.q);
                quantity.setText(product.getQuantity());

        return listItemView;
    }
//--------------------------------------------------------
@Override
public boolean isEnabled(int position) {
    return true;
}
}

